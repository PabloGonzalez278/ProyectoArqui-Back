using Microsoft.EntityFrameworkCore;
using ProductsService.API.Models;  

namespace ProductsService.API.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        { }

        public DbSet<Product> Products { get; set; }  // Asegúrate de que el modelo Product esté en la misma solución
    }
}

