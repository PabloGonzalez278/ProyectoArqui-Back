using Grpc.Core;
using Logic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace LogicService
{
    public class ProductLogicService : ProductLogic.ProductLogicBase
    {
        private readonly HttpClient _httpClient;

        public ProductLogicService(HttpClient httpClient)
        {
            _httpClient = httpClient;
            _httpClient.BaseAddress = new Uri("http://products-api"); // Nombre del servicio en docker-compose
        }

        public override async Task<ProductList> GetAllProducts(Empty request, ServerCallContext context)
        {
            int maxRetries = 5;
            int delayMs = 2000;

            for (int attempt = 1; attempt <= maxRetries; attempt++)
            {
                try
                {
                    var products = await _httpClient.GetFromJsonAsync<List<ProductDto>>("/api/products");

                    var response = new ProductList();
                    if (products != null)
                    {
                        response.Products.AddRange(products.Select(p => new Product
                        {
                            Id = p.Id,
                            Name = p.Name,
                            Price = p.Price
                        }));
                    }

                    return response;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[Intento {attempt}] Error al consumir el API REST: {ex.Message}");

                    if (attempt == maxRetries)
                    {
                        throw new RpcException(new Status(StatusCode.Internal, "Error en la lógica del servidor"));
                    }

                    await Task.Delay(delayMs);
                }
            }

            // Nunca llega aquí, pero el compilador lo necesita
            return new ProductList();
        }

        private class ProductDto
        {
            public int Id { get; set; }
            public string Name { get; set; }
            public double Price { get; set; }
        }
    }
}

