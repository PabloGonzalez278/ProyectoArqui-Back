using Grpc.Net.Client;
using Logic;
using System;
using System.Net.Http;
using System.Net.Sockets;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        var handler = new SocketsHttpHandler
        {
            EnableMultipleHttp2Connections = true,
            ConnectCallback = async (context, cancellationToken) =>
            {
                var socket = new Socket(SocketType.Stream, ProtocolType.Tcp);
                await socket.ConnectAsync("logic-service", 80, cancellationToken);
                return new NetworkStream(socket, ownsSocket: true);
            }
        };

        using var channel = GrpcChannel.ForAddress("http://logic-service", new GrpcChannelOptions
        {
            HttpHandler = handler
        });

        var client = new ProductLogic.ProductLogicClient(channel);

        int maxRetries = 5;
        int delayMs = 5000;

        for (int attempt = 1; attempt <= maxRetries; attempt++)
        {
            try
            {
                var response = await client.GetAllProductsAsync(new Empty());

                foreach (var product in response.Products)
                {
                    Console.WriteLine($"Producto: {product.Id} - {product.Name} - ${product.Price}");
                }

                return; // 
            }
            catch
            {
                if (attempt == maxRetries)
                {
                    Console.WriteLine("Error: no se pudo conectar al servicio gRPC.");
                    return;
                }

                await Task.Delay(delayMs); // 
            }
        }
    }
}

